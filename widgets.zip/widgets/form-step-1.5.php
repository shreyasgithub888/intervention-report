<?php

$sql = "SELECT * FROM `ir_header_details` WHERE `ir_status` = 'Thank you' and `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $thankYouRow = mysqli_fetch_assoc($result);
    $thankYouHeaderImage = $thankYouRow["header_image_url"];
    $thankYouHeaderExcerpt = $thankYouRow["header_excerpt"];
}

?>
<form method="POST" action="" class="form-horizontal" name="thankYouHeader" id="thankYouHeader" data-form-id="1.5">
    <h3 class="page-title text-white text-center header_title_report_stage" id="header_title_report_stage">
        THANK YOU HEADER
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text"></div>
    <div class="form-group">
        <label for="header_image" class="col-md-3 col-sm-3 col-xs-6 control-label">Header Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="thankYouHeaderImage" name="header_image" />
            <input type="hidden" class="existing_image" value="<?php echo trim($thankYouHeaderImage) ?>" />
        </div>

        <button class="btn btn-success preview_img" data-img="<?php echo trim($thankYouHeaderImage) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>

    </div>
    <div class="form-group">
        <label for="header_excerpt" class="col-md-3 col-sm-3 col-xs-6 control-label">Excerpt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="header_excerpt" name="header_excerpt"
                value="<?php echo $thankYouHeaderExcerpt ?>" />
        </div>
    </div>

    <center style="padding-bottom:15px;">

        <button type="button" onclick="previousDoor('#thankYouHeader')" class="btn btn-primary hide"><span
                class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary thankYouHeaderBtn">Next&nbsp;<span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>



</form>