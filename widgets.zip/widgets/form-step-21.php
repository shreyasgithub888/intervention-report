<?php
$record_id = $_GET['id'];
$thankYouThanksQuery = "SELECT * FROM `ir_thank_you` WHERE `ir_status` = 'Thank you' and `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $thankYouThanksQuery);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $thankYouThanksImage = $row["image1_url"];
    $thankYouThanksText = $row["text1"];
    $thankYouThanksFootnotes = $row["footnotes"];
}
?>
<form method="POST" action="" class="form-horizontal" name="stepTwentyOne" id="stepTwentyOne" data-form-id="21">
    <h3 class="page-title text-white text-center">
        THANK YOU
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text"></div>
    <div class="form-group">
        <label for="thankYouThanksImage" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="thankYouThanksImage" name="thankYouThanksImage">
            <input type="hidden" class="existing_image" value="<?php echo trim($thankYouThanksImage) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($thankYouThanksImage) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
    </div>
    <div class="form-group">
        <label for="thankYouThanksText" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control" id="thankYouThanksText"
                name="thankYouThanksText"><?php echo $thankYouThanksText ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="thankYouThanksFootnotes"
            class="col-md-3 col-sm-3 col-xs-6 control-label">thankYouThanksFootnotes</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control" id="thankYouThanksFootnotes" name="thankYouThanksFootnotes">
               <?php echo $thankYouThanksFootnotes ?>
            </textarea>
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepTwentyOne')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" id="submit-data" class="btn btn-primary stepTwentyOneBtn">Submit</button>
    </center>
</form>