<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_difference_made` WHERE `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // var_dump("row ", $row);
    $difference_made_image = $row["image1_url"];
    $difference_made_alt = $row["image1_alt"];
    $difference_made_text = $row["text1"];
}

?>
<form method="POST" action="" class="form-horizontal" name="stepFourteen" id="stepFourteen" data-form-id="14">
    <h3 class="page-title text-white text-center">
        THE DIFFERENCE YOU HAVE MADE
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
    <div class="form-group">
        <label for="difference_made_image" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="difference_made_image" name="difference_made_image" />
            <input type="hidden" class="existing_image" value="<?php echo trim($difference_made_image) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($difference_made_image) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
    </div>
    <div class="form-group">
        <label for="difference_made_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="difference_made_alt" name="difference_made_alt"
                value="<?php echo trim($difference_made_alt) ?>" />
        </div>
    </div>
    <div class="form-group">
        <label for="difference_made_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="difference_made_text" name="difference_made_text"><?php echo $difference_made_text ?></textarea>
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepFourteen')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepFourteenBtn">Next&nbsp;<span class="icon"><img class="btn-icon"
                    src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>