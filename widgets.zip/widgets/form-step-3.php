<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_story_of_success` WHERE `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $sub_header_two = $row["sub_header"];
    $story_success_text = $row["text"];
    $image_file_three = $row["image1_url"];
    $story_success_image_alt = $row["image1_alt"];
	$quotes_title = $row["quotes_title"];
	$quotes_by = $row["quotes_by"];
}
?>
<form method="POST" action="" class="form-horizontal" name="stepThree" id="stepThree" data-form-id="3">
    <h3 class="page-title text-white text-center">
        STORY OF SUCCESS:
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
    <div class="form-group">
        <label for="sub_header_two" class="col-md-3 col-sm-3 col-xs-6 control-label">Sub-Header</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="sub_header_two" name="sub_header_two"
                value="<?php echo $sub_header_two ?>" />
        </div>
    </div>
    <div class="form-group">
        <label for="story_success_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6">
            <textarea type="text" class="form-control" id="story_success_text"
                name="story_success_text"><?php echo $story_success_text ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="image_file_three" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="image_file_three" name="image_file_three" />
            <input type="hidden" class="existing_image" value="<?php echo trim($image_file_three) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($image_file_three) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
    </div>
    <div class="form-group">
        <label for="image_file_three_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="image_file_three_alt" name="image_file_three_alt"
                value="<?php echo trim($story_success_image_alt) ?>" />
        </div>
    </div>
     <div class="form-group">
        <label for="quotes_title" class="col-md-3 col-sm-3 col-xs-6 control-label">Quote title</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="quotes_title" name="quotes_title"
                value="<?php echo trim($quotes_title) ?>" />
        </div>
    </div>
    <div class="form-group">
        <label for="quotes_by" class="col-md-3 col-sm-3 col-xs-6 control-label">Quote by</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="quotes_by" name="quotes_by"
                value="<?php echo trim($quotes_by) ?>" />
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepThree')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepThreeBtn">Next&nbsp;<span class="icon"><img class="btn-icon"
                    src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>