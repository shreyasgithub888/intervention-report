<?php
$record_id = $_GET['id'];
$thankYouUpdateQuery = "SELECT * FROM `ir_thank_you` WHERE `ir_status` = 'Update' and `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $thankYouUpdateQuery);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $thankYouUpdateImage = $row["image1_url"];
    $thankYouUpdateText = $row["text1"];
    $thankYouUpdateFootnotes = $row["footnotes"];
}
?>
<form method="POST" action="" class="form-horizontal" name="stepTwenty" id="stepTwenty" data-form-id="21">
    <h3 class="page-title text-white text-center">
        THANK YOU
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text"></div>
    <div class="form-group">
        <label for="thankYouUpdateImage" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="thankYouUpdateImage" name="thankYouUpdateImage">
            <input type="hidden" class="existing_image" value="<?php echo trim($thankYouUpdateImage) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($thankYouUpdateImage) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
    </div>
    <div class="form-group">
        <label for="thankYouUpdateText" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control" id="thankYouUpdateText"
                name="thankYouUpdateText"><?php echo $thankYouUpdateText ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="thankYouUpdateFootnotes"
            class="col-md-3 col-sm-3 col-xs-6 control-label">thankYouUpdateFootnotes</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control" id="thankYouUpdateFootnotes" name="thankYouUpdateFootnotes">
               <?php echo $thankYouUpdateFootnotes ?>
            </textarea>
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepTwenty')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" id="submit-data" class="btn btn-primary stepTwentyBtn">Submit</button>
    </center>
</form>