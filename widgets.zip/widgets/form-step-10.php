<form method="POST" action="" class="form-horizontal" name="stepTen" id="stepTen" data-form-id="10">
    <h3 class="page-title text-white text-center">
        BUDGET
    </h3>
    <div class="error-text" style=""></div>
    <div class="form-group">
        <label for="input_csv_file" class="col-md-4 col-sm-3 col-xs-6 control-label">CSV</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="input_csv_file" name="input_csv_file">
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('stepTen')" class="btn btn-primary">Previous</button>
        <button type="submit" class="btn btn-primary stepTenBtn">Next</button>
    </center>
</form>