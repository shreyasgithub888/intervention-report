<?php
	$record_id = $_GET['id'];
    $sql = "SELECT * FROM `ir_activity_report` WHERE `ir_id` = $record_id";
    $result = mysqli_query($ir_conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
		// var_dump("row ", $row);
		$activity_icon_one = $row["icon1_url"];
		$activity_text_one = $row["text1"];
		$activity_icon_two = $row["icon2_url"];
		$activity_text_two = $row["text2"];
		$image1_alt_first = $row["icon1_alt"];
		$image1_alt_second = $row["icon2_alt"];
    }

?>
<form method="POST" action="" class="form-horizontal" name="stepTwelve" id="stepTwelve" data-form-id="12">
    <h3 class="page-title text-white text-center">
        ACTIVITY REPORT
    </h3>
	<input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
   <!-- <div class="form-group">
        <label for="activity_icon_one" class="col-md-3 col-sm-3 col-xs-6 control-label">Icon</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="activity_icon_one" name="activity_icon_one">
			 <input type="hidden" class="existing_image" value="<?php echo trim($activity_icon_one) ?>" />
        </div>
		
		  <button class="btn btn-success preview_img" data-img="<?php echo trim($activity_icon_one) ?>"
            type="button">Preview</button>
          <button class="btn btn-danger delete_img" type="button">Delete</button>
		
		<!--<?php if (!empty($activity_icon_one)) { ?>
		    <div class="col-md-4 col-sm-3 col-xs-6"></div>
		    <div class="col-md-6 col-sm-3 col-xs-6 preview-image" style="padding-top:10px;">
                <button class="btn btn-success preview_img" data-img="<?php echo trim($activity_icon_one) ?>">Preview</button>
            </div>
		<?php } ?>
		
    </div>
	
	 <div class="form-group">
        <label for="image1_alt_first" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="image1_alt_first" name="image1_alt_first"
                value="<?php echo trim($image1_alt_first) ?>" />
        </div>
    </div>-->
    <div class="form-group">
        <label for="activity_text_one" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="activity_text_one" name="activity_text_one"><?php echo $activity_text_one ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="activity_icon_two" class="col-md-3 col-sm-3 col-xs-6 control-label">Icon</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="activity_icon_two" name="activity_icon_two" />
			<input type="hidden" class="existing_image" value="<?php echo trim($activity_icon_two) ?>" />
        </div>
		
		 <button class="btn btn-success preview_img" data-img="<?php echo trim($activity_icon_two) ?>"
            type="button">Preview</button>
          <button class="btn btn-danger delete_img" type="button">Delete</button>
		  
		<!--<?php if (!empty($activity_icon_two)) { ?>
		    <div class="col-md-4 col-sm-3 col-xs-6"></div>
		    <div class="col-md-6 col-sm-3 col-xs-6 preview-image" style="padding-top:10px;">
                <button class="btn btn-success preview_img" data-img="<?php echo trim($activity_icon_two) ?>">Preview</button>
            </div>
		<?php } ?>-->
		
		
    </div>
	 <div class="form-group">
        <label for="image1_alt_second" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="image1_alt_second" name="image1_alt_second"
                value="<?php echo trim($image1_alt_second) ?>" />
        </div>
    </div>
   <!-- <div class="form-group">
        <label for="activity_text_two" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="activity_text_two" name="activity_text_two"><?php echo $activity_text_two ?></textarea>
        </div>
    </div>-->
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepTwelve')" class="btn btn-primary"><span class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepTwelveBtn">Next&nbsp;<span class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>