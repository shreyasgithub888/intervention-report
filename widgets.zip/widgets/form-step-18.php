<?php
    $record_id = $_GET['id'];
    $sql = "SELECT * FROM `ir_budget_details` WHERE `ir_id` = $record_id";
    $result = mysqli_query($ir_conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $budget_text = $row['budget_text'];
    }
?>
<form method="POST" action="" class="form-horizontal" name="stepEighteen" id="stepEighteen" data-form-id="18">
    <h3 class="page-title text-white text-center">
        BUDGET
    </h3>
    <div style="display: flex; justify-content: end; margin-bottom: 20px;">
        <a href="<?php echo $root?>/intervention_report/uploads/sample_csv/Test_Proposal_Budget.csv"
            class="btn btn-primary" Download> Download Sample CSV</a>
    </div>
    <div class="error-text" style=""></div>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="form-group">
        <label for="budget_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control budget_text" id="budget_text"
                name="budget_text"><?php echo $budget_text ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="input_csv_1" class="col-md-4 col-sm-3 col-xs-6 control-label">CSV</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="input_csv_1" name="input_csv_1"
                accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, text/csv" />
        </div>
    </div>
    <!-- <div class="form-group">
        <label for="image_file_19" class="col-md-4 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="image_file_19" name="image_file_19">
        </div>
    </div> -->

    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepEighteen')" class="btn btn-primary">Previous</button>
        <button type="submit" class="btn btn-primary stepEighteenBtn">Next</button>
    </center>
</form>