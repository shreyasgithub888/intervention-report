<?php
   $record_id = $_GET['id'];
    $sql = "SELECT * FROM `ir_cost` WHERE `ir_id` = $record_id";
    $result = mysqli_query($ir_conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        // var_dump("row ", $row);
        // $report_stage = $row["report_stage"];
		$cost_text = $row["text"];
    }
	$sql2 = "SELECT * FROM `ir_budget` WHERE `ir_id` = $record_id";
    $result2 = mysqli_query($ir_conn, $sql2);
    $budgetFormData = mysqli_num_rows($result2);
 if (mysqli_num_rows($result2) > 0) {
        $row2 = mysqli_fetch_assoc($result2);
        // var_dump("row ", $row);
        $file_url = $row2["file_url"];
		// var_dump($file_url);
        // $input_csv_file_1 = $row2["item"];
    }
?>

<form method="POST" action="" class="form-horizontal" name="stepNine" id="stepNine" data-form-id="9">
    <h3 class="page-title text-white text-center">
        COST & BUDGET
    </h3>
	<input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
	    <div style="display: flex; justify-content: end; margin-bottom: 20px;">
        <a href="<?php echo $root?>/intervention_report/uploads/sample_csv/Test_Proposal_Budget.csv" class="btn btn-primary" Download> Download Sample CSV</a>
    </div>
    <div class="form-group">
        <label for="cost_text" class="col-md-4 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="cost_text" name="cost_text"><?php echo $cost_text ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="input_csv_file_1" class="col-md-4 col-sm-3 col-xs-6 control-label">CSV</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="input_csv_file_1" name="input_csv_file_1"
                accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, text/csv" />
            <input type="hidden" class="existing_image" value="<?php echo $file_url?>" />
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepNine')" class="btn btn-primary"><span class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepNineBtn">Next&nbsp;<span class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>