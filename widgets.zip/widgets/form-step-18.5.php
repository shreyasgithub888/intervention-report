<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_budget_details_thank_you` WHERE `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $budget_text_thankyou = $row['budget_text'];
}

$sql2 = "SELECT * FROM `ir_budget_thankyou` WHERE `ir_id` = $record_id";
$result2 = mysqli_query($ir_conn, $sql2);
$budgetFormData = mysqli_num_rows($result2);
if (mysqli_num_rows($result2) > 0) {
    $row2 = mysqli_fetch_assoc($result2);
    // var_dump("row ", $row);
    $bugdet_file_url = $row2["file_url"];
    // $input_csv_file_1 = $row2["item"];
}
?>
<form method="POST" action="" class="form-horizontal" name="stepEighteen_Half" id="stepEighteen_Half" data-form-id="18.5">
    <h3 class="page-title text-white text-center">
        BUDGET
    </h3>
    <div style="display: flex; justify-content: end; margin-bottom: 20px;">
        <a href="<?php echo $root ?>/intervention_report/uploads/sample_csv/Test_Proposal_Budget.csv" class="btn btn-primary" Download> Download Sample CSV</a>
    </div>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="form-group">
        <label for="budget_text_thankyou" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control budget_text_thankyou" id="budget_text_thankyou" name="budget_text_thankyou"><?php echo $budget_text_thankyou ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="input_csv_1" class="col-md-3 col-sm-3 col-xs-6 control-label">CSV</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="input_csv_1" name="input_csv_1" accept=".csv, text/csv" />
            <input type="hidden" class="existing_image" value="<?php echo $bugdet_file_url ?>" />
        </div>
    </div>
    <div class="error-text"></div>
    <div class="success-text"></div>
    <!--<div class="form-group">
        <label for="budgetImage" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="budgetImage" name="budgetImage" />
            <input type="hidden" class="existing_image" value="<?php echo trim($budgetImage) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($budgetImage) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
    </div>
    <div class="form-group">
        <label for="budgetAlt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="budgetAlt" name="budgetAlt"
                value="<?php echo trim($budget_image1_alt) ?>" />
        </div>
    </div>-->

    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepEighteen_Half')" class="btn btn-primary">Previous</button>
        <button type="submit" class="btn btn-primary stepEighteen_HalfBtn">Next</button>
    </center>
</form>