<?php
   $record_id = $_GET['id'];
    $sql = "SELECT * FROM `ir_monitoring_and_evaluation` WHERE `ir_id` = $record_id";
    $result = mysqli_query($ir_conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
		$monitoring_and_evolution_text = $row["text"];
    }
 
?>


<form method="POST" action="" class="form-horizontal" name="stepSeven" id="stepSeven" data-form-id="7">
    <h3 class="page-title text-white text-center">
        MONITORING AND EVALUATION
    </h3>
	<input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
    <div class="form-group">
        <label for="monitoring_and_evolution_text" class="col-md-4 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="monitoring_and_evolution_text" name="monitoring_and_evolution_text"><?php echo $monitoring_and_evolution_text ?></textarea>
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepSeven')" class="btn btn-primary"><span class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepSevenBtn">Next&nbsp;<span class="icon"><img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>