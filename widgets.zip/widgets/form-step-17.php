<?php
$record_id = $_GET['id'];
$sql1 = "SELECT * FROM `ir_gallery` WHERE `ir_id` = $record_id";
$result1 = mysqli_query($ir_conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);
$gallary_text = $row1["gal_text"];

$sql = "SELECT * FROM `ir_gallery_image` WHERE `ir_id` = $record_id ORDER BY `ir_gallery_image`.`created_at` ASC";
$result = mysqli_query($ir_conn, $sql);

$galleryforms = mysqli_num_rows($result);
$imageCount = 0;


?>
<form method="POST" action="" class="form-horizontal" name="stepSeventeen" id="stepSeventeen" data-form-id="17">
    <h3 class="page-title text-white text-center">
        GALLERY
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text"></div>
    <div class="form-group" style="display: flex;    justify-content: end;">
        <div class="col-md-6 col-sm-3 col-xs-6 " style="display: flex;    justify-content: end;">
            <button type="button" class="btn addNew">Add new Image</button>
        </div>
    </div>
    <div class="form-group">
        <label for="gallary_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control gallary_text" id="gallary_text" name="gallary_text"><?php echo $gallary_text ?></textarea>
        </div>
    </div>
    <?php
    if ($galleryforms > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $galleryImage = $row["image_url"];
            $galleryImageAlt = $row["image_alt"];
            // $gallary_text = $row["text"];

    ?>
            <div class="addNewForm addNewFormUpdate">
                <div class="form-group">
                    <label for="galleryImage" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
                    <div class="col-md-6 col-sm-3 col-xs-6 ">
                        <input type="file" class="form-control galleryImage" id="galleryImage<?php echo $imageCount; ?>" name="galleryImage[0]" required />
                        <input type="hidden" class="existing_image" value="<?php echo trim($galleryImage) ?>" />
                    </div>
                    <button class="btn btn-success preview_img" data-img="<?php echo trim($galleryImage) ?>" type="button">Preview</button>
                    <button class="btn btn-danger delete_img" type="button">Delete</button>
                    <?php if ($imageCount > 0) { ?>
                        <button class="btn btn-danger removeGalleryImage" type="button">Remove</button>
                    <?php } ?>
                </div>
                <div class="form-group">
                    <label for="galleryImageAlt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
                    <div class="col-md-6 col-sm-3 col-xs-6 ">
                        <input type="text" class="form-control galleryImageAlt" name="galleryImageAlt[0]" value="<?php echo trim($galleryImageAlt) ?>" required />
                    </div>
                </div>
            </div>
        <?php
            $imageCount++;
        }
    } else {
        // Show a single form
        ?>
        <div class="addNewForm addNewFormUpdate">
            <div class="form-group">
                <label for="galleryImage" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
                <div class="col-md-6 col-sm-3 col-xs-6 ">
                    <input type="file" class="form-control galleryImage" id="galleryImage<?php echo $imageCount; ?>" name="galleryImage[0]" required />
                    <input type="hidden" class="existing_image" value="<?php echo trim($galleryImage) ?>" />
                </div>
                <button class="btn btn-success preview_img" data-img="<?php echo trim($galleryImage) ?>" type="button">Preview</button>
                <button class="btn btn-danger delete_img" type="button">Delete</button>
            </div>
            <div class="form-group">
                <label for="galleryImageAlt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
                <div class="col-md-6 col-sm-3 col-xs-6 ">
                    <input type="text" class="form-control galleryImageAlt" name="galleryImageAlt[0]" value="" required />
                </div>
            </div>
        </div>
    <?php
    }
    ?>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepSeventeen')" class="btn btn-primary"><span class="icon"><img class="btn-icon" src="<?php echo $root ?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepSeventeenBtn">Next&nbsp;<span class="icon"><img class="btn-icon" src="<?php echo $root ?>/images/arrow-right.png"></span></button>
    </center>
</form>