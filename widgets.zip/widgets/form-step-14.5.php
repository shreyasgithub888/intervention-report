<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_impact_made` WHERE `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // var_dump("row ", $row);
    $impact_made_text = $row["impactText"];
    $impact_made_image = $row["impactImage"];
    $impact_made_image_alt = $row["impactAlt"];
}

?>
<form method="POST" action="" class="form-horizontal" name="stepFourteen_Half" id="stepFourteen_Half" data-form-id="14.5">
    <h3 class="page-title text-white text-center">
        IMPACT MADE
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
    <div class="form-group">
        <label for="impact_made_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6">
				<textarea type="text" class="form-control" id="impact_made_text" name="impact_made_text"><?php echo $impact_made_text ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="impact_made_image" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="impact_made_image" name="impact_made_image" />
            <input type="hidden" class="existing_image" value="<?php echo trim($impact_made_image) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($impact_made_image) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
        <!--<?php if (!empty($image_file_three)) { ?>
		    <div class="col-md-4 col-sm-3 col-xs-6"></div>
		    <div class="col-md-6 col-sm-3 col-xs-6 preview-image" style="padding-top:10px;">
                <button class="btn btn-success preview_img" data-img="<?php echo trim($image_file_three) ?>">Preview</button>
            </div>
		<?php } ?>-->

    </div>
    <div class="form-group">
        <label for="impact_made_image_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="impact_made_image_alt" name="impact_made_image_alt"
                value="<?php echo trim($impact_made_image_alt) ?>" />
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepFourteen_Half')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepFourteen_Half_Btn">Next&nbsp;<span class="icon"><img class="btn-icon"
		src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>