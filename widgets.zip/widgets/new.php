<?php
$record_id = $_GET['id'];

// Fetch background and context details
$sql1 = "SELECT * FROM `ir_background_and_context` WHERE `ir_id` = $record_id";
$result1 = mysqli_query($ir_conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);
$background_context_text = $row1["text"];

// Fetch background and context images
$sql2 = "SELECT * FROM `ir_background_and_context_images` WHERE `ir_id` = $record_id";
$result2 = mysqli_query($ir_conn, $sql2);

?>

<!-- Display the fetched details in the form -->
<form method="POST" action="" class="form-horizontal" name="stepFour" id="stepFour" data-form-id="4">
    <!-- Rest of your form code -->

    <div class="form-group">
        <label for="background_context_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control background_context_text" id="background_context_text"
                name="background_context_text"><?php echo $background_context_text ?></textarea>
        </div>
    </div>

    <!-- Display the fetched images and alt text -->
    <?php while ($row2 = mysqli_fetch_assoc($result2)) { ?>
    <div class="addNewBackForm">
        <div class="form-group">
            <label for="background_context_img" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
            <div class="col-md-6 col-sm-3 col-xs-6">
                <input type="file" class="form-control background_context_img" id="background_context_img"
                    name="background_context_img[]" required />
                <!-- Display existing image URL -->
                <input type="hidden" class="existing_image" value="<?php echo $row2['image1_url']; ?>" />
            </div>
            <!-- Add preview and delete buttons -->
            <button class="btn btn-success preview_img" data-img="<?php echo $row2['image1_url']; ?>"
                type="button">Preview</button>
            <button class="btn btn-danger delete_img" type="button">Delete</button>
        </div>

        <div class="form-group">
            <label for="background_context_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
            <div class="col-md-6 col-sm-3 col-xs-6">
                <!-- Display existing alt text -->
                <input type="text" class="form-control background_context_alt" name="background_context_alt[]"
                    value="<?php echo $row2['image1_alt']; ?>" required />
            </div>
        </div>
    </div>
    <?php } ?>

    <!-- Rest of your form code -->
</form>
