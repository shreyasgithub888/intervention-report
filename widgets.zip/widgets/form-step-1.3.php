<?php

$fetchProposalQuery = "SELECT * FROM `ir_header_details` WHERE `ir_status` = 'Proposal' and `ir_id` = $record_id";
$fetchProposalResult = mysqli_query($ir_conn, $fetchProposalQuery);

if (mysqli_num_rows($fetchProposalResult) > 0) {
    $proposalRow = mysqli_fetch_assoc($fetchProposalResult);
    $proposalHeaderImage = $proposalRow["header_image_url"];
    $proposalHeaderExcerpt = $proposalRow["header_excerpt"];
}

?>
<form method="POST" action="" class="form-horizontal" name="proposalHeader" id="proposalHeader" data-form-id="1.3">
    <h3 class="page-title text-white text-center header_title_report_stage" id="header_title_report_stage">
        PROPOSAL HEADER
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text"></div>
    <div class="form-group">
        <label for="header_image" class="col-md-3 col-sm-3 col-xs-6 control-label">Header Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="proposalHeaderImage" name="header_image" />
            <input type="hidden" class="existing_image" value="<?php echo trim($proposalHeaderImage) ?>" />
        </div>

        <button class="btn btn-success preview_img" data-img="<?php echo trim($proposalHeaderImage) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>

    </div>
    <div class="form-group">
        <label for="header_excerpt" class="col-md-3 col-sm-3 col-xs-6 control-label">Excerpt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="header_excerpt" name="header_excerpt"
                value="<?php echo $proposalHeaderExcerpt ?>" />
        </div>
    </div>

    <center style="padding-bottom:15px;">

        <button type="button" onclick="previousDoor('#proposalHeader')" class="btn btn-primary hide"><span
                class="icon"><img class="btn-icon" src="<?php echo $root?>images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary proposalHeaderBtn">Next&nbsp;<span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>images/arrow-right.png"></span></button>
    </center>



</form>