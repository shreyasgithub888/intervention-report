<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_background_and_context` WHERE `ir_id` = $record_id";
$result1 = mysqli_query($ir_conn, $sql);
$row1 = mysqli_fetch_assoc($result1);
$background_context_text = $row1["text"];


$sql2 = "SELECT * FROM `ir_background_and_context_images` WHERE `ir_id` = $record_id";
$result2 = mysqli_query($ir_conn, $sql2);
$backandcontextForms = mysqli_num_rows($result2);
$imageCount = 0;

?>
<form method="POST" action="" class="form-horizontal" name="stepFour" id="stepFour" data-form-id="4">
    <h3 class="page-title text-white text-center">
        BACKGROUND AND CONTEXT
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text"></div>
	 <div class="form-group" style="display: flex; justify-content: end;">
        <div class="col-md-6 col-sm-3 col-xs-6" style="display: flex; justify-content: end;">
            <button type="button" class="btn addNewBack">Add new Image</button>
        </div>
    </div>
     <div class="form-group">
        <label for="background_context_text" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control background_context_text" id="background_context_text" name="background_context_text"><?php echo $background_context_text ?></textarea>
        </div>
    </div>	
   

    <?php
    if ($backandcontextForms > 0) {
        while ($row2 = mysqli_fetch_assoc($result2)) {
            $background_context_img = $row2["image1_url"];
            $background_context_alt = $row2["image1_alt"];

    ?>
    <div class="addNewBackForm">
        <div class="form-group">
            <label for="background_context_img" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
            <div class="col-md-6 col-sm-3 col-xs-6">
                <input type="file" class="form-control background_context_img" id="background_context_img<?php echo $imageCount; ?>" name="background_context_img[0]" required />
                <input type="hidden" class="existing_image" value="<?php echo trim($background_context_img) ?>" />
            </div>
            <button class="btn btn-success preview_img" data-img="<?php echo trim($background_context_img) ?>"
                type="button">Preview</button>
            <button class="btn btn-danger delete_img" type="button">Delete</button>
			<?php if ($imageCount > 0) { ?>
            <button class="btn btn-danger removeBackgroundContextImage" type="button">Remove</button>
            <?php } ?>
        </div>

        <div class="form-group">
            <label for="background_context_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
            <div class="col-md-6 col-sm-3 col-xs-6">
                <input type="text" class="form-control background_context_alt" name="background_context_alt[0]"
                    value="<?php echo trim($background_context_alt) ?>" required />
            </div>
        </div>
    </div>
    <?php
            $imageCount++;
        }
    } else {
        // Show a single form
        ?>
    <div class="addNewBackForm">
        <div class="form-group">
            <label for="background_context_img" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
            <div class="col-md-6 col-sm-3 col-xs-6">
                <input type="file" class="form-control background_context_img" id="background_context_img<?php echo $imageCount; ?>" name="background_context_img[0]" required />
                <input type="hidden" class="existing_image"  value="<?php echo trim($background_context_img) ?>" />
            </div>
            <button class="btn btn-success preview_img" data-img="<?php echo trim($background_context_img) ?>" type="button">Preview</button>
            <button class="btn btn-danger delete_img" type="button">Delete</button>
        </div>

        <div class="form-group">
            <label for="background_context_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
            <div class="col-md-6 col-sm-3 col-xs-6">
                <input type="text" class="form-control background_context_alt" name="background_context_alt[0]" value="" required />
            </div>
        </div>
    </div>
    <?php
       }
    ?>
    <center style="padding-bottom: 15px;">
        <button type="button" onclick="previousDoor('#stepFour')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon"
                    src="<?php echo $root?>/images/arrow-right.png"
                    style="transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepFourBtn">Next&nbsp;<span class="icon"><img class="btn-icon"
                    src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>
