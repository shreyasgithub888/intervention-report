<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_intervention_report` WHERE `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $report_stage = $row["report_stage"];
    $post_title = $row["post_title"];
    $ir_url = $row["ir_url"];
}
?>
<form method="POST" action="" class="form-horizontal" name="stepOne" id="stepOne" data-form-id="1"
    enctype="multipart/form-data">
    <h3 class="page-title text-white text-center">
        INTERVENTION REPORT
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <input type="hidden" class="report_stage" id="report_stage" name="report_stage"
        value="<?php echo !empty($report_stage) ? $report_stage : "Proposal"; ?>" />


    <?php if($report_stage === "Update"){ ?>
    <div class="form-group">
        <label for="post_title" class="col-md-3 col-sm-3 col-xs-6 control-label">Report Stage</label>
        <div class="col-md-9 col-sm-3 col-xs-6">
            <button type="button" class="reportStageBtn btn" data-value="Proposal">Select Proposal stage and click
                Next</button>
        </div>
    </div>
    <?php } else if($report_stage === "Proposal"){ ?>
    <div class="form-group">
        <label for="post_title" class="col-md-3 col-sm-3 col-xs-6 control-label">Report Stage</label>
        <div class="col-md-9 col-sm-3 col-xs-6">
            <button type="button" class="reportStageBtn btn" data-value="Update"> Select Update stage and click
                Next</button>
            <p style="    font-weight: bold;    color: white;">*The selected stage is Proposal by default*</p>
        </div>
    </div>
    <?php }  ?>

    <!--<div class="form-group">
        <label for="report_stage" class="col-md-3 col-sm-3 col-xs-6 control-label">Report stage </label>
        <div class="col-md-6 col-sm-3 col-xs-6">
            <input type="radio" name="report_stage" class="report_stage" value="Proposal"
                <?php echo $report_stage === "Proposal" ? "checked" : ""; ?> />
            <label class="control-label">Proposal</label>

            <input type="radio" name="report_stage" class="report_stage" value="Update"
                <?php echo $report_stage === "Update" ? "checked" : ""; ?> />
            <label class="control-label">Update</label>

            <input type="radio" name="report_stage" class="report_stage" value="Thank you"
                <?php echo $report_stage === "Thank you" ? "checked" : ""; ?> />
            <label class="control-label">Thank you</label>
        </div>
    </div>-->
    <div class="form-group">
        <label for="post_title" class="col-md-3 col-sm-3 col-xs-6 control-label">Post Title</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="post_title" name="post_title" value="<?php echo $post_title ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="ir_url" class="col-md-3 col-sm-3 col-xs-6 control-label">URL:</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="ir_url" name="ir_url" value="<?php echo $ir_url ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="country_type" class="col-md-3 col-sm-3 col-xs-6 control-label">Country</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <select name="country_type" class="form-control" id="country_type">
                <?php
                foreach ($countryarr as $x => $x_value) {
                    if ($row["country_id"] == $x) {
                        echo '<option value="' . $x . '" selected="selected">' . $x_value . '</option>';
                    } else {
                        echo '<option value="' . $x . '">' . $x_value . '</option>';
                    }
                }
                ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label for="category_type" class="col-md-3 col-sm-3 col-xs-6 control-label">Intervention</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <select name="category_type" class="form-control" id="category_type">
                <option value="" <?php echo !isset($row["category"]) ? "selected" : ""; ?>>Select a category</option>
                <option value="Child Survival"
                    <?php echo isset($row["category"]) && $row["category"] === "Child Survival" ? "selected" : ""; ?>>
                    Child Survival</option>
                <option value="Water"
                    <?php echo isset($row["category"]) && $row["category"] === "Water" ? "selected" : ""; ?>>Water
                </option>
                <option value="Health"
                    <?php echo isset($row["category"]) && $row["category"] === "Health" ? "selected" : ""; ?>>Health
                </option>
                <option value="Stability"
                    <?php echo isset($row["category"]) && $row["category"] === "Stability" ? "selected" : ""; ?>>
                    Stability</option>
                <option value="Education"
                    <?php echo isset($row["category"]) && $row["category"] === "Education" ? "selected" : ""; ?>>
                    Education</option>
                <option value="Child Protection"
                    <?php echo isset($row["category"]) && $row["category"] === "Child Protection" ? "selected" : ""; ?>>
                    Child Protection</option>
            </select>
        </div>
    </div>
    <div class="error-text"></div>
    <div class="success-text"></div>
    <center style="padding-bottom:15px;">
        <button type="submit" class="stepOneF btn btn-primary">Next&nbsp;
            <span class="icon">
                <img class="btn-icon" src="<?php echo $root?>/images/arrow-right.png">
            </span>
    </center>
</form>