<?php
   $record_id = $_GET['id'];
    $sql = "SELECT * FROM `ir_objectives` WHERE `ir_id` = $record_id";
    $result = mysqli_query($ir_conn, $sql);
	$ObjectiveForms = mysqli_num_rows($result);
    $iconCount = 0;
?>
<form method="POST" action="" class="form-horizontal" name="stepSix" id="stepSix" data-form-id="6"
    enctype="multipart/form-data">
    <h3 class="page-title text-white text-center">
        OBJECTIVES
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
    <div class="form-group" style="display: flex; justify-content: end;">
        <div class="col-md-6 col-sm-3 col-xs-6" style="display: flex; justify-content: end;">
            <button type="button" class="btn addiconobjectives">Add objective</button>
        </div>
    </div>
    <?php
    if ($ObjectiveForms > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $objectivesIcon = $row["icon1_url"];
            $objectivesText = $row["text1"];
    ?>
    <div class="addnewobjectives">
        <div class="form-group">
            <label for="objectivesIcon" class="col-md-3 col-sm-3 col-xs-6 control-label">Icon</label>
            <div class="col-md-6 col-sm-3 col-xs-6 ">
                <input type="file" class="form-control objectivesIcon" id="objectivesIcon<?php echo $iconCount; ?>"
                    name="objectivesIcon[0] " required />
                <input type="hidden" class="existing_image" value="<?php echo trim($objectivesIcon) ?>" />
            </div>
            <button class="btn btn-success preview_img" data-img="<?php echo trim($objectivesIcon) ?>"
                type="button">Preview</button>
            <button class="btn btn-danger delete_img" type="button">Delete</button>
            <?php if ($iconCount > 0) { ?>
            <button class="btn btn-danger removeSection" data-form-name="addnewobjectives" type="button">Remove</button>
            <?php } ?>
        </div>
        <div class="form-group">
            <label for="objectivesText" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
            <div class="col-md-6 col-sm-3 col-xs-6 ">
                <input type="text" class="form-control objectivesText" id="objectivesText" name="objectivesText[0]"
                    value="<?php echo $objectivesText ?>" required></input>
            </div>
        </div>
    </div>
    <?php
            $iconCount++;
        }
    } else {
        // Show a single form
    ?>
    <div class="addnewobjectives">
        <div class="form-group">
            <label for="objectivesIcon" class="col-md-3 col-sm-3 col-xs-6 control-label">Icon</label>
            <div class="col-md-6 col-sm-3 col-xs-6 ">
                <input type="file" class="form-control objectivesIcon" id="objectivesIcon" name="objectivesIcon[0] "
                    required />
                <input type="hidden" class="existing_image" />
            </div>
            <button class="btn btn-success preview_img" data-img="" type="button">Preview</button>
            <button class="btn btn-danger delete_img" type="button">Delete</button>
        </div>
        <div class="form-group">
            <label for="objectivesText" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
            <div class="col-md-6 col-sm-3 col-xs-6 ">
                <input type="text" class="form-control objectivesText" id="objectivesText[0]" name="objectivesText[0]"
                    required></input>
            </div>
        </div>
    </div>
    <?php
       }
    ?>
    <div class="error-text"></div>
    <div class="success-text"></div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepSix')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepSixBtn">Next&nbsp;<span class="icon"><img class="btn-icon"
                    src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>