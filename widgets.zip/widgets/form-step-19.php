<?php
$record_id = $_GET['id'];
$thankYouProposalQuery = "SELECT * FROM `ir_thank_you` WHERE `ir_stage` = '$report_stage' and `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $thankYouProposalQuery);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $thankYouProposalImage = $row["image1_url"];
    $thankYouProposalText = $row["text1"];
    $thankYouProposalFootnotes = $row["footnotes"];
}
?>
<form method="POST" action="" class="form-horizontal" name="stepNineteen" id="stepNineteen" data-form-id="19">
    <h3 class="page-title text-white text-center">
        THANK YOU
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <input type="hidden" id="report_stage" name="report_stage" value="<?php echo $report_stage; ?>" />
    <div class="error-text"></div>
    <div class="form-group">
        <label for="thankYouProposalImage" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="thankYouProposalImage" name="thankYouProposalImage">
            <input type="hidden" class="existing_image" value="<?php echo trim($thankYouProposalImage) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($thankYouProposalImage) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>
    </div>
    <div class="form-group">
        <label for="thankYouProposalText" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control" id="thankYouProposalText"
                name="thankYouProposalText"><?php echo $thankYouProposalText ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="thankYouProposalFootnotes" class="col-md-3 col-sm-3 col-xs-6 control-label">Footnotes</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <textarea type="text" class="form-control" id="thankYouProposalFootnotes" name="thankYouProposalFootnotes">
               <?php echo $thankYouProposalFootnotes ?>
            </textarea>
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepNineteen')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" id="submit-data" class="btn btn-primary stepNineteenBtn">Submit</button>
    </center>
</form>