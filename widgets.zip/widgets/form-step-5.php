<?php
$record_id = $_GET['id'];
$sql = "SELECT * FROM `ir_agroecology_center_details` WHERE `ir_id` = $record_id";
$result = mysqli_query($ir_conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // var_dump("row ", $row);

    $sub_header_three = $row["sub_header"];
    $agroecology_details_text_one = $row["text1"];
    $image_file_five = $row["image1_url"];
    $image_file_six = $row["image2_url"];
    $agroecology_details_text_two = $row["text2"];
    $image1_agro_alt = $row["image1_alt"];
    $image2_agro_alt = $row["image2_alt"];
}

?>
<form method="POST" action="" class="form-horizontal" name="stepFive" id="stepFive" data-form-id="5"
    novalidate="novalidate">
    <h3 class="page-title text-white text-center">
        AGROECOLOGY CENTRE DETAILS
    </h3>
    <input type="hidden" id="existing_ir_id" name="existing_ir_id" value="<?php echo $record_id; ?>" />
    <div class="error-text" style=""></div>
    <div class="form-group">
        <label for="sub_header_three" class="col-md-3 col-sm-3 col-xs-6 control-label">Sub-Header</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="sub_header_three" name="sub_header_three"
                value="<?php echo $sub_header_three ?>" />
        </div>
    </div>
    <div class="form-group">
        <label for="agroecology_details_text_one" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="agroecology_details_text_one" name="agroecology_details_text_one"><?php echo $agroecology_details_text_one ?></textarea>
        </div>
    </div>
    <div class="form-group">
        <label for="image_file_five" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="image_file_five" name="image_file_five">
            <input type="hidden" class="existing_image" value="<?php echo trim($image_file_five) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($image_file_five) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>

        <!--<?php if (!empty($image_file_five)) { ?>
		    <div class="col-md-4 col-sm-3 col-xs-6"></div>
		    <div class="col-md-6 col-sm-3 col-xs-6 preview-image" style="padding-top:10px;">
                <button class="btn btn-success preview_img" data-img="<?php echo trim($image_file_five) ?>">Preview</button>
            </div>
		<?php } ?>-->

    </div>

    <div class="form-group">
        <label for="image_file_five_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="image_file_five_alt" name="image_file_five_alt"
                value="<?php echo trim($image1_agro_alt) ?>" />
        </div>
    </div>

    <div class="form-group">
        <label for="image_file_six" class="col-md-3 col-sm-3 col-xs-6 control-label">Image</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="file" class="form-control" id="image_file_six" name="image_file_six">
            <input type="hidden" class="existing_image" value="<?php echo trim($image_file_six) ?>" />
        </div>
        <button class="btn btn-success preview_img" data-img="<?php echo trim($image_file_six) ?>"
            type="button">Preview</button>
        <button class="btn btn-danger delete_img" type="button">Delete</button>

        <!--<?php if (!empty($image_file_six)) { ?>
		    <div class="col-md-4 col-sm-3 col-xs-6"></div>
		    <div class="col-md-6 col-sm-3 col-xs-6 preview-image" style="padding-top:10px;">
                <button class="btn btn-success preview_img" data-img="<?php echo trim($image_file_six) ?>">Preview</button>
            </div>
		<?php } ?>-->

    </div>

    <div class="form-group">
        <label for="image_file_six_alt" class="col-md-3 col-sm-3 col-xs-6 control-label">Image alt</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
            <input type="text" class="form-control" id="image_file_six_alt" name="image_file_six_alt"
                value="<?php echo trim($image2_agro_alt) ?>" />
        </div>
    </div>

    <div class="form-group">
        <label for="agroecology_details_text_two" class="col-md-3 col-sm-3 col-xs-6 control-label">Text</label>
        <div class="col-md-6 col-sm-3 col-xs-6 ">
			<textarea type="text" class="form-control" id="agroecology_details_text_two" name="agroecology_details_text_two"><?php echo $agroecology_details_text_two ?></textarea>
        </div>
    </div>
    <center style="padding-bottom:15px;">
        <button type="button" onclick="previousDoor('#stepFive')" class="btn btn-primary"><span class="icon"><img
                    class="btn-icon" src="<?php echo $root?>/images/arrow-right.png" style="
    transform: rotate(180deg);"></span>&nbsp;Previous</button>
        <button type="submit" class="btn btn-primary stepFiveBtn">Next&nbsp;<span class="icon"><img class="btn-icon"
                    src="<?php echo $root?>/images/arrow-right.png"></span></button>
    </center>
</form>